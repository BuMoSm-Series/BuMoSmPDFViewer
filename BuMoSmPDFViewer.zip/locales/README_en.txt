================================================================
BuMoSm PDF Viewer — Language File Guide
================================================================

Language files are JSON files placed in this folder.
Each file defines the display strings for one language.
The application loads all .json files here at startup.

To add a language, copy en.json, rename it to the language
code (e.g. fr.json for French), and translate the strings.
The new language appears in the Settings panel on the next
launch.


----------------------------------------------------------------
FILE NAME
----------------------------------------------------------------

The file name (without the .json extension) is used as the
language code. Use the ISO 639-1 two-letter code:

  en.json   English
  ja.json   Japanese
  fr.json   French
  de.json   German
  ... and so on


----------------------------------------------------------------
FILE STRUCTURE
----------------------------------------------------------------

The file is a JSON object. Strings are grouped into sections:

  {
    "section": {
      "key": "Display string"
    }
  }

The application looks up strings by "section.key".
The reference below uses that notation.


----------------------------------------------------------------
PLACEHOLDERS
----------------------------------------------------------------

Some strings contain placeholders in the form %{name}.
They are replaced at runtime with a number or a name.

  %{position}  Which match you are on, while searching
  %{total}     Total number of search matches
  %{count}     Number of pages
  %{version}   PDF version number (e.g. 1.7)
  %{name}      File name (without the path)
  %{path}      Full path to a file
  %{detail}    Error details returned by the system

You may move a placeholder to fit your language's word order.
Do not delete or rename it — an unrecognized placeholder is
printed literally, so %{name} would appear on screen as-is.

Write a line break inside a string as \n.
Two in a row (\n\n) leave a blank line.


----------------------------------------------------------------
FALLBACK
----------------------------------------------------------------

If a key is missing from your file, the English string from
en.json is used instead. A partial translation still works, so
you can translate only the parts you need.

To find untranslated strings, run the application, switch to
your language, and look for text still shown in English.
Those are the keys you have not translated yet.


================================================================
STRING REFERENCE (all 100 entries)
================================================================

Every key is listed below with where it appears on screen.
The text in parentheses is the string from en.json.


----------------------------------------------------------------
locale — Language information (2 entries)
----------------------------------------------------------------

  language
    Label of the language selector in the Settings panel.
    (Language)

  language_name
    Name of this language, shown in the language list in the
    Settings panel. (English)
    Write it as the language names itself — "Deutsch" for
    German, not "German".


----------------------------------------------------------------
app — General (1 entry)
----------------------------------------------------------------

  drop_message
    Shown in the center of the window when no PDF is open.
    (Drop a PDF file here)


----------------------------------------------------------------
toolbar — Toolbar (31 entries)
----------------------------------------------------------------

Most of these are button tooltips. The key names in
parentheses are keyboard shortcuts — leave them untranslated.

  history
    Tooltip of the recent files button. (Recent files)

  open
    Tooltip of the open file button. (Open a PDF file)

  outline
    Tooltip of the button that shows or hides the outline
    panel. (Toggle the outline (F4))

  thumbnails
    Tooltip of the button that shows or hides the thumbnail
    panel. (Toggle thumbnails)

  zoom_out
    Tooltip of the zoom out button. (Zoom out)

  zoom_in
    Tooltip of the zoom in button. (Zoom in)

  zoom_reset
    Tooltip of the actual size button.
    (Reset to actual size (Ctrl+0))

  fit_width
    Tooltip of the fit to width button.
    (Fit to width (Ctrl+1))

  fit_page
    Tooltip of the fit whole page button.
    (Fit the whole page (Ctrl+2))

  rotate_ccw
    Tooltip of the counter-clockwise rotate button.
    (Rotate counter-clockwise (Ctrl+Shift+-))

  rotate_cw
    Tooltip of the clockwise rotate button.
    (Rotate clockwise (Ctrl+Shift++))

  more
    Tooltip of the "..." button that collects the buttons
    that did not fit in the toolbar when the window is
    narrow. (More tools)

  first_page
    Tooltip of the page number button pointing at the first
    page. (First page (Home))

  prev_page
    Tooltip of the page number button one before the current
    page. (Previous page)

  next_page
    Tooltip of the page number button one after the current
    page. (Next page)

  last_page
    Tooltip of the page number button pointing at the last
    page. (Last page (End))

  current_page
    Tooltip of the page number button for the page currently
    shown. (Current page)

  prev_page_list
    When there are too many pages to show every number, this
    is the tooltip of the "..." button that collects the
    pages before the current one. (Earlier pages)

  next_page_list
    Same, for the pages after the current one. (Later pages)

  page_input
    Tooltip of the field for typing a page number directly.
    (Go to page)

  zoom_input
    Tooltip of the field for typing a zoom level directly.
    (Set zoom)

  view_mode
    Tooltip of the view mode toggle button.
    (Switch between continuous and single page)

  settings
    Tooltip of the settings button. (Settings)

  page_layout
    Tooltip of the page layout toggle button.
    (Switch between single page and two-page spread)

  layout_single
    Text on the page layout button when showing one page.
    Also used for the "Page layout" options in Settings.
    (Single)
    NOTE: shown on a button — keep it short.

  layout_spread
    Same, when showing a two-page spread. (Spread)
    NOTE: shown on a button — keep it short.

  mode_continuous
    Text on the view mode button when scrolling continuously.
    Also used for the "View mode" options in Settings.
    (Cont.)
    NOTE: shown on a button — keep it short. English
    abbreviates "Continuous" to "Cont.".

  mode_single
    Same, when showing a single page. (Single)
    NOTE: shown on a button — keep it short.

  zoom_actual
    Text on the zoom button at actual size. (Actual)
    NOTE: shown on a button — keep it short.

  zoom_fit_width
    Same, when fitted to width. (Width)
    NOTE: shown on a button — keep it short.

  zoom_fit_page
    Same, when fitted to the whole page. (Page)
    NOTE: shown on a button — keep it short.


----------------------------------------------------------------
sidebar — Sidebar tabs (3 entries)
----------------------------------------------------------------

All three are shown on tabs, where width is limited.
Keep them short.

  outline
    Name of the outline tab. (Contents)

  thumbnails
    Name of the thumbnail tab. (Thumbnails)

  search_hits
    Name of the search results tab. (Results)


----------------------------------------------------------------
search — Search bar (11 entries)
----------------------------------------------------------------

  placeholder
    Faint text shown in the search field while it is empty.
    (Text to find)

  prev_hit
    Tooltip of the previous match button.
    (Previous match (Shift+F3))

  next_hit
    Tooltip of the next match button. (Next match (F3))

  match_case
    Tooltip of the case sensitivity toggle. (Match case)

  whole_word
    Tooltip of the whole word toggle.
    (Match whole word only)

  close
    Tooltip of the button that closes the search bar.
    (Close (Esc))

  hit_list
    Tooltip of the button that opens the list of search
    results. (Search results)

  not_found
    Shown in the search bar when nothing matched.
    (No matches)

  searching
    Shown while a search has started but nothing has been
    found yet. (Searching...)

  hits
    The match counter. (%{position} / %{total})
    %{position} is the match you are currently on.
    %{total} is how many were found.

  hits_searching
    The match counter while the search is still running.
    (%{position} / %{total} (searching...))
    Indicates the total is still going up.


----------------------------------------------------------------
menu — Context menu (1 entry)
----------------------------------------------------------------

  copy
    The copy item shown when right-clicking on a page. (Copy)


----------------------------------------------------------------
password — Password dialog (6 entries)
----------------------------------------------------------------

Shown when opening a password-protected PDF.

  title
    Title of the dialog. (Enter password)

  message
    Body text. (%{name} is password protected.)
    %{name} is the name of the file being opened.

  placeholder
    Faint text shown in the password field while it is empty.
    (Password)

  wrong
    Shown after entering an incorrect password.
    (Incorrect password. Please try again.)

  ok
    Button that submits the password and opens the file.
    (Open)

  cancel
    Button that gives up opening the file. (Cancel)


----------------------------------------------------------------
history — Recent files (5 entries)
----------------------------------------------------------------

  missing_title
    Title of the dialog shown when a file from the history no
    longer exists. (File not found)

  missing_message
    Its body text. %{path} is the full path of the file.
    (%{path}\n\nThe file has been moved or deleted.
     It was removed from the history.)
    The path is followed by a blank line, then the
    explanation.

  empty
    Shown in the list when there are no recent files.
    (No recent files)

  forget
    Item that removes one file from the history.
    (Remove from history)

  clear
    Item that clears the whole history. (Clear all)


----------------------------------------------------------------
status — Status bar (2 entries)
----------------------------------------------------------------

  pages
    Total page count. (%{count} pages)
    %{count} is the number of pages.

  version
    PDF version. (PDF %{version})
    %{version} is a number such as 1.7.


----------------------------------------------------------------
settings — Settings panel (21 entries)
----------------------------------------------------------------

  title
    Heading of the settings panel. (Settings)

  theme
    Label of the theme selector. (Theme)

  theme_system
    The first item in the theme list, which follows the
    system appearance. (Follow the system)

  theme_builtin
    Group heading in the theme list for themes built into the
    application. (Built-in)

  theme_files
    Group heading in the theme list for themes loaded from
    the themes folder. (Theme files)

  history_limit
    Label of the field for how many recent files to keep.
    (Number of recent files)

  restore_page
    Label of the toggle for resuming at the last page.
    (Open at the last page)

  scroll_speed
    Label of the scroll speed field. (Scroll speed)

  scroll_easing
    Label of the scroll acceleration field.
    (Scroll acceleration)

  battery_saver
    Label of the toggle for lowering the frame rate on
    battery power. (Lower the frame rate on battery)

  default_pdf_set
    Button shown when this application is not the default
    PDF app. Pressing it opens the Windows default apps
    settings screen. (Set as default PDF app)

  default_pdf_unset
    Button shown when this application is already the
    default PDF app. Pressing it opens the Windows default
    apps settings screen. (Unset as default PDF app)

  initial_view_mode
    Label of the selector for the view mode used when
    opening a PDF. (View mode)
    Its options use toolbar.mode_continuous and
    toolbar.mode_single.

  initial_zoom
    Label of the selector for the zoom level used when
    opening a PDF. (Initial zoom)
    Its options use toolbar.zoom_actual,
    toolbar.zoom_fit_width and toolbar.zoom_fit_page.

  initial_page_layout
    Label of the selector for the page layout used when
    opening a PDF. (Page layout)
    Its options use toolbar.layout_single and
    toolbar.layout_spread.

  spread_cover
    Label of the selector for how the cover page is handled
    in spread view. (Cover page)

  cover_separate
    Its option: show the first page by itself. (Show alone)

  cover_paired
    Its option: pair pages starting from the first one.
    (Pair from the first page)

  binding
    Label of the binding direction selector. (Binding)
    Affects the page order in spread view.

  binding_left
    Its option: left-bound. (Left-bound)

  binding_right
    Its option: right-bound. (Right-bound)

  apply
    Button that applies the settings. (Apply)

  cancel
    Button that discards the settings and closes the panel.
    (Cancel)


----------------------------------------------------------------
error — Error dialogs (6 entries)
----------------------------------------------------------------

  pdfium_title
    Title shown when the PDF rendering engine could not be
    loaded. (Cannot load the PDF engine)

  pdfium_message
    Its body text. %{detail} is the error detail returned by
    the system.
    (Failed to load the pdfium library.\n\nPlace pdfium.dll
     in the same folder as the executable.\n\nDetails:
     %{detail})
    Appears at startup when pdfium.dll cannot be found.

  open_title
    Title shown when a PDF could not be opened.
    (Cannot open the PDF)

  open_format
    Body text when the file was readable but could not be
    parsed as a PDF. %{name} is the file name.
    (Failed to open %{name}.\n\nThe file may be damaged, or
     it may not be a PDF.)

  open_file
    Body text when the file itself could not be read.
    %{name} is the file name. Appears when the file was moved
    or deleted, or when read permission is missing.
    (Could not read %{name}.\n\nThe file may have been moved
     or deleted, or you may not have permission to read it.)

  open_other
    Body text for any other reason the file could not be
    opened. %{name} is the file name.
    (Failed to open %{name}.)


----------------------------------------------------------------
message_box — Dialog buttons (7 entries)
----------------------------------------------------------------

Button labels used across the various dialogs. They are not
all shown at once; the set depends on the situation.

  ok       Confirm button. (OK)
  cancel   Cancel button. (Cancel)
  yes      Yes button. (Yes)
  no       No button. (No)
  retry    Retry button. (Retry)
  abort    Abort button. (Abort)
  ignore   Button that ignores the problem and continues.
           (Ignore)


----------------------------------------------------------------
dialog — File open dialog (2 entries)
----------------------------------------------------------------

These are passed to the Windows file open dialog.

  open_title
    Text shown in the dialog's title bar.
    (Open a PDF file)

  pdf_filter
    Text shown in the file type selector.
    (PDF files (*.pdf))
    NOTE: the (*.pdf) part is the extension pattern that
    Windows interprets. Keep it in that form.


----------------------------------------------------------------
tab — Tabs (2 entries)
----------------------------------------------------------------

  untitled
    Name shown on a tab with no PDF open. (Untitled)

  close
    Tooltip of the tab close button. (Close tab)


================================================================
EXAMPLE: ADDING FRENCH (fr.json)
================================================================

1. Copy en.json to fr.json in this folder.

2. Edit the "locale" section:

     "locale": {
       "language": "Langue",
       "language_name": "Français"
     }

3. Translate the string values.
   Do not change the key names on the left. A renamed key is
   never found, so its English text is shown instead.

4. Restart the application.
   "Français" appears in the language list in Settings.

5. Switch to it and look through the screens. Anything still
   in English has not been translated yet.

================================================================
