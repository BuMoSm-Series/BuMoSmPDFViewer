================================================================
BuMoSm PDF Viewer — 言語ファイルの説明
================================================================

このフォルダに .json ファイルを置くと、アプリ起動時に
言語ファイルとして読み込まれます。
1つのファイルが1つの言語の表示文字列を定義します。

言語を追加するには、en.json をコピーして言語コードの名前に
変更し（例: フランス語なら fr.json）、文字列を翻訳してください。
次の起動から設定画面の言語一覧に表示されます。


----------------------------------------------------------------
ファイル名
----------------------------------------------------------------

ファイル名（.json を除いた部分）が言語コードとして使われます。
ISO 639-1 の2文字コードを使用してください。

  en.json   英語 (English)
  ja.json   日本語
  fr.json   フランス語 (Français)
  de.json   ドイツ語 (Deutsch)
  など


----------------------------------------------------------------
ファイルの構造
----------------------------------------------------------------

ファイルはJSONオブジェクトです。文言はセクションごとに
まとめられています。

  {
    "section": {
      "key": "表示する文字列"
    }
  }

アプリは "section.key" という形式で文字列を引きます。
以降の一覧はこの形式で表記します。


----------------------------------------------------------------
プレースホルダ
----------------------------------------------------------------

一部の文字列には %{名前} の形式のプレースホルダが含まれます。
実行時に数字や名前へ置き換えられます。

  %{position}  検索で、いま何件目にいるか
  %{total}     検索の総ヒット数
  %{count}     ページ数
  %{version}   PDFのバージョン番号（例: 1.7）
  %{name}      ファイル名（パスを含まない）
  %{path}      ファイルのフルパス
  %{detail}    エラーの詳細（システムが返した内容）

語順の都合で位置を入れ替えるのは問題ありません。
ただし削除したり、名前を変えたりしないでください。
置き換えが行われず、%{name} のまま画面に出ます。

文字列の途中で改行するには \n と書きます。
\n\n と2つ続けると1行空きます。


----------------------------------------------------------------
フォールバック
----------------------------------------------------------------

ファイルにキーが無い場合、en.json の英語文字列が使われます。
すべてのキーを翻訳しなくても動作するので、部分的に訳した
状態でも問題ありません。

翻訳漏れを探すときは、アプリを起動して自分の言語に切り替え、
英語のまま残っている箇所を探してください。
それが未翻訳のキーです。


================================================================
文言の一覧（全132項目）
================================================================

以下、すべてのキーと、それが画面のどこに出るかを記載します。
括弧内は en.json の文言です。


----------------------------------------------------------------
locale — 言語の情報（2項目）
----------------------------------------------------------------

  language
    設定画面の言語セレクターの見出し。（Language）

  language_name
    設定画面の言語一覧に出る、この言語の名前。（English）
    その言語自身の表記で書いてください。
    ドイツ語なら "German" ではなく "Deutsch" とします。


----------------------------------------------------------------
app — アプリ全般（1項目）
----------------------------------------------------------------

  drop_message
    PDFを開いていないときに画面中央へ出る案内文。
    （Drop a PDF file here）


----------------------------------------------------------------
toolbar — ツールバー（33項目）
----------------------------------------------------------------

ほとんどがボタンのツールチップです。括弧内のキー表記は
ショートカットキーなので、翻訳せずそのまま残してください。

  history
    表示履歴ボタンのツールチップ。（Recent files）

  open
    ファイルを開くボタンのツールチップ。（Open a PDF file）

  outline
    目次パネルの開閉ボタンのツールチップ。
    （Toggle the outline (F4)）

  thumbnails
    サムネイルパネルの開閉ボタンのツールチップ。
    （Toggle thumbnails）

  zoom_out
    縮小ボタンのツールチップ。（Zoom out）

  zoom_in
    拡大ボタンのツールチップ。（Zoom in）

  zoom_reset
    等倍に戻すボタンのツールチップ。
    （Reset to actual size (Ctrl+0)）

  fit_width
    幅に合わせるボタンのツールチップ。
    （Fit to width (Ctrl+1)）

  fit_page
    ページ全体表示ボタンのツールチップ。
    （Fit the whole page (Ctrl+2)）

  rotate_ccw
    反時計回り回転ボタンのツールチップ。
    （Rotate counter-clockwise (Ctrl+Shift+-)）

  rotate_cw
    時計回り回転ボタンのツールチップ。
    （Rotate clockwise (Ctrl+Shift++)）

  more
    ウィンドウ幅が足りずツールバーに収まらなかったボタンを
    まとめる、「…」ボタンのツールチップ。（More tools）

  first_page
    ページ番号ボタンのうち、先頭ページを指すもののツールチップ。
    （First page (Home)）

  prev_page
    現在ページの1つ前を指すページ番号ボタンのツールチップ。
    （Previous page）

  next_page
    現在ページの1つ後を指すページ番号ボタンのツールチップ。
    （Next page）

  last_page
    末尾ページを指すページ番号ボタンのツールチップ。
    （Last page (End)）

  current_page
    いま表示しているページ番号ボタンのツールチップ。
    （Current page）

  prev_page_list
    ページ数が多く番号を省略しているとき、現在ページより前を
    まとめた「…」ボタンのツールチップ。（Earlier pages）

  next_page_list
    同じく、現在ページより後ろをまとめた「…」ボタンの
    ツールチップ。（Later pages）

  page_input
    ページ番号を直接入力する欄のツールチップ。（Go to page）

  zoom_input
    倍率を直接入力する欄のツールチップ。（Set zoom）

  view_mode
    表示モード切り替えボタンのツールチップ。
    （Switch between continuous and single page）

  settings
    設定ボタンのツールチップ。（Settings）

  fullscreen
    全画面表示の切り替えボタンのツールチップ。
    （Toggle fullscreen）

  go_back
    表示履歴を1つ戻るボタンのツールチップ。
    （Back to the previous view）

  go_forward
    表示履歴を1つ進むボタンのツールチップ。
    （Forward to the next view）

  search
    テキスト検索を開くボタンのツールチップ。
    （Search the text）

  page_layout
    ページの並べ方を切り替えるボタンのツールチップ。
    （Switch between single page and two-page spread）

  layout_single
    ページの並べ方ボタンに出る文字（1ページ表示のとき）。
    設定画面の「ページの並べ方」の選択肢にも使われます。
    （Single）
    ※ボタン上に表示されるため、短い訳語にしてください。

  layout_spread
    同じく見開き表示のときの文字。（Spread）
    ※ボタン上に表示されるため、短い訳語にしてください。

  mode_continuous
    表示モードボタンに出る文字（連続スクロールのとき）。
    設定画面の「表示モード」の選択肢にも使われます。（Cont.）
    ※ボタン上に表示されるため、短い訳語にしてください。
      英語では Continuous を Cont. と略しています。

  mode_single
    同じく単一ページ表示のときの文字。（Single）
    ※ボタン上に表示されるため、短い訳語にしてください。

  zoom_actual
    倍率ボタンに出る文字（等倍のとき）。（Actual）
    ※ボタン上に表示されるため、短い訳語にしてください。

  zoom_fit_width
    同じく幅に合わせているときの文字。（Width）
    ※ボタン上に表示されるため、短い訳語にしてください。

  zoom_fit_page
    同じくページ全体を表示しているときの文字。（Page）
    ※ボタン上に表示されるため、短い訳語にしてください。

  bookmarks
    ブックマークパネルの開閉ボタンのツールチップ。（Bookmarks）

  last_read
    「ここまで読んだ」ページへ移るボタンのツールチップ。
    （Go to where you left off）


----------------------------------------------------------------
sidebar — サイドバーのタブ（4項目）
----------------------------------------------------------------

いずれもタブに表示される文字です。幅が限られるため、
短い訳語にしてください。

  outline
    目次パネルのタブ名。（Contents）

  thumbnails
    サムネイルパネルのタブ名。（Thumbnails）

  search_hits
    検索結果パネルのタブ名。（Results）

  bookmarks
    ブックマークパネルのタブ名。（Bookmarks）


----------------------------------------------------------------
search — 検索バー（15項目）
----------------------------------------------------------------

  placeholder
    検索入力欄が空のときに薄く表示される案内文。
    （Text to find）

  prev_hit
    前の一致へ移動するボタンのツールチップ。
    （Previous match (Shift+F3)）

  next_hit
    次の一致へ移動するボタンのツールチップ。
    （Next match (F3)）

  match_case
    大文字小文字を区別する切り替えボタンのツールチップ。
    （Match case）

  whole_word
    単語単位で一致させる切り替えボタンのツールチップ。
    （Match whole word only）

  close
    検索バーを閉じるボタンのツールチップ。（Close (Esc)）

  hit_list
    検索結果の一覧を開閉するボタンのツールチップ。
    （Search results）

  not_found
    検索して一致が無かったときに検索バーへ出る文字。
    （No matches）

  searching
    検索を始めたばかりで、まだ1件も見つかっていないときの表示。
    （Searching...）

  hits
    見つかった件数の表示。（%{position} / %{total}）
    %{position} は、いま何件目を選んでいるか。
    %{total} は見つかった総数。

  hits_searching
    検索がまだ続いている間の件数表示。
    （%{position} / %{total} (searching...)）
    総数が増えている途中であることを示します。

  history
    検索履歴を開くボタンのツールチップ。（Search history）

  history_empty
    その文書でまだ一度も検索していないときに、
    履歴の一覧へ出る文字。（No search history）

  history_forget
    履歴1件を消すボタンのツールチップ。（Remove from history）

  history_clear
    その文書の検索履歴をすべて消すボタンの文字。（Clear all）


----------------------------------------------------------------
menu — 右クリックメニュー（5項目）
----------------------------------------------------------------

  copy
    ページ上で右クリックしたときに出る、コピー項目。（Copy）

  select_all
    キーの一覧に出す、全選択の名前。（Select all）

  bookmark_add
    ブックマークされていないページを右クリックしたときに出る項目。
    （Add bookmark）

  bookmark_remove
    ブックマーク済みのページを右クリックしたときに出る項目。
    （Remove bookmark）

  last_read
    いま見ているページを「ここまで読んだ」として記録する項目。
    （Read up to here）


----------------------------------------------------------------
bookmark — ブックマーク（15項目）
----------------------------------------------------------------

ブックマークはページに名前を付けて登録する目印です。
サイドパネルに一覧が出て、押すとそのページへ移動します。

一覧の先頭には「ここまで読んだ」が並びます。
こちらは文書につき1つだけで、名前を変えられません。

  empty
    ブックマークが1件も無いときにパネルの中央に出る文字。
    （No bookmarks）

  last_read
    一覧の先頭に出る「ここまで読んだ」の行の名前。
    利用者が付けた名前ではなく、この文言がそのまま表示されます。
    （Read up to here）

  remove
    各行の削除ボタンのツールチップ。（Remove）

  rename
    各行の名前変更ボタンのツールチップ。（Rename）

  clear
    すべてのブックマークを消すボタンの文字。（Clear all）

  dialog_title
    ブックマークを追加するダイアログのタイトル。（Add Bookmark）

  dialog_message
    追加ダイアログの説明文。（Enter a name for this bookmark.）

  dialog_ok
    追加ダイアログの確定ボタン。（Add）

  name_placeholder
    名前入力欄が空のときに薄く表示される案内文。（Bookmark name）

  rename_title
    名前変更ダイアログのタイトル。（Rename Bookmark）

  rename_message
    名前変更ダイアログの説明文。
    （Enter a new name for this bookmark.）

  rename_ok
    名前変更ダイアログの確定ボタン。（Rename）

  error_title
    重複エラーダイアログのタイトル。（Cannot Add Bookmark）

  error_page
    同じページに既にブックマークがある場合のエラー文。
    （This page already has a bookmark.）

  error_name
    同じ名前が既にある場合のエラー文。
    （This name is already used.）


----------------------------------------------------------------
password — パスワード入力ダイアログ（6項目）
----------------------------------------------------------------

パスワードで保護されたPDFを開いたときに表示されます。

  title
    ダイアログのタイトル。（Enter password）

  message
    本文。（%{name} is password protected.）
    %{name} は開こうとしたファイルの名前。

  placeholder
    パスワード入力欄が空のときの案内文。（Password）

  wrong
    間違ったパスワードを入力したときに出る文字。
    （Incorrect password. Please try again.）

  ok
    パスワードを確定して開くボタン。（Open）

  cancel
    開くのをやめるボタン。（Cancel）


----------------------------------------------------------------
history — 表示履歴（5項目）
----------------------------------------------------------------

  missing_title
    履歴から開こうとしたファイルが見つからなかったときの
    ダイアログのタイトル。（File not found）

  missing_message
    その本文。%{path} は開こうとしたファイルのフルパス。
    （%{path}\n\nThe file has been moved or deleted.
      It was removed from the history.）
    パスの後ろで2行空けてから説明が続きます。

  empty
    履歴が1件も無いときに一覧へ出る文字。（No recent files）

  forget
    履歴1件を消す項目。（Remove from history）

  clear
    履歴をすべて消す項目。（Clear all）


----------------------------------------------------------------
status — ステータスバー（2項目）
----------------------------------------------------------------

  pages
    総ページ数の表示。（%{count} pages）
    %{count} はページ数。

  version
    PDFのバージョン表示。（PDF %{version}）
    %{version} は 1.7 のような番号。


----------------------------------------------------------------
settings — 設定パネル（32項目）
----------------------------------------------------------------

  title
    設定パネルの見出し。（Settings）

  group_display
    設定を区切る見出し。表示のしかたに関する項目をまとめる。
    （Display）

  group_history
    設定を区切る見出し。履歴に関する項目をまとめる。（History）

  group_behavior
    設定を区切る見出し。スクロールなどの動きに関する項目を
    まとめる。（Behavior）

  group_other
    設定を区切る見出し。どれにも入らない項目をまとめる。（Other）

  theme
    配色の選択欄の見出し。（Theme）

  theme_system
    配色一覧の先頭にある、OSの設定に従う項目。
    （Follow the system）

  theme_builtin
    配色一覧の中で、アプリに内蔵されているテーマを
    まとめるグループの見出し。（Built-in）

  theme_files
    配色一覧の中で、themes フォルダから読み込んだテーマを
    まとめるグループの見出し。（Theme files）

  history_limit
    開いたファイルの履歴に残す件数の入力欄の見出し。
    （File history count）

  search_history_limit
    1つの文書で検索履歴に残す件数の入力欄の見出し。
    （Search history count）

  restore_page
    開くページの選択欄の見出し。（Opening page）

  restore_off
    「開くページ」の選択肢。常に先頭から開く。（First page）

  restore_on
    「開くページ」の選択肢。前回見ていたページから開く。
    （Last viewed page）

  scroll_speed
    スクロール速度の入力欄の見出し。（Scroll speed）

  scroll_easing
    スクロールの加減速度の入力欄の見出し。
    （Scroll acceleration）

  battery_saver
    バッテリー動作時の設定の選択欄の見出し。（On battery）

  battery_off
    「バッテリー動作時」の選択肢。フレームレートを下げない。
    （Normal FPS）

  battery_on
    「バッテリー動作時」の選択肢。フレームレートを下げる。
    （Reduce FPS）


  default_pdf_set
    このアプリが .pdf の既定アプリになっていないときに出る
    ボタンの文言。押すとWindowsの既定アプリ設定画面が開きます。
    （既定のPDFアプリに設定する）

  default_pdf_unset
    このアプリが .pdf の既定アプリになっているときに出る
    ボタンの文言。押すとWindowsの既定アプリ設定画面が開きます。
    （既定のPDFアプリを解除する）

  initial_view_mode
    PDFを開いたときの表示モードの選択欄の見出し。
    （View mode）
    選択肢の文字は toolbar.mode_continuous と
    toolbar.mode_single を使います。

  initial_zoom
    PDFを開いたときの倍率の選択欄の見出し。（Initial zoom）
    選択肢の文字は toolbar.zoom_actual、zoom_fit_width、
    zoom_fit_page を使います。

  initial_page_layout
    PDFを開いたときのページの並べ方の選択欄の見出し。
    （Page layout）
    選択肢の文字は toolbar.layout_single と
    toolbar.layout_spread を使います。

  spread_cover
    見開き表示のときの、表紙の扱いを選ぶ欄の見出し。
    （Cover page）

  cover_separate
    その選択肢。1ページ目を単独で置く。（Show alone）

  cover_paired
    その選択肢。1ページ目から2枚ずつ並べる。
    （Pair from the first page）

  binding
    綴じ方向の選択欄の見出し。（Binding）
    見開き表示のときのページの並び順に影響します。

  binding_left
    その選択肢。左綴じ。（Left-bound）

  binding_right
    その選択肢。右綴じ。（Right-bound）

  apply
    設定を確定するボタン。（Apply）

  cancel
    設定を破棄して閉じるボタン。（Cancel）


----------------------------------------------------------------
error — エラーダイアログ（6項目）
----------------------------------------------------------------

  pdfium_title
    PDF描画エンジンを読み込めなかったときのタイトル。
    （Cannot load the PDF engine）

  pdfium_message
    その本文。%{detail} はシステムが返したエラーの詳細。
    （Failed to load the pdfium library.\n\nPlace pdfium.dll
      in the same folder as the executable.\n\nDetails: %{detail}）
    起動時に pdfium.dll が見つからない場合などに出ます。

  open_title
    PDFを開けなかったときのタイトル。
    （Cannot open the PDF）

  open_format
    ファイルは読めたが、PDFとして解釈できなかったときの本文。
    %{name} はファイル名。
    （Failed to open %{name}.\n\nThe file may be damaged,
      or it may not be a PDF.）

  open_file
    ファイル自体を読めなかったときの本文。%{name} はファイル名。
    移動・削除された場合や、読み取り権限が無い場合に出ます。
    （Could not read %{name}.\n\nThe file may have been moved
      or deleted, or you may not have permission to read it.）

  open_other
    上のどちらにも当てはまらない理由で開けなかったときの本文。
    %{name} はファイル名。（Failed to open %{name}.）


----------------------------------------------------------------
message_box — ダイアログのボタン（7項目）
----------------------------------------------------------------

各種ダイアログで使われるボタンの文字です。
すべてが同時に出るわけではなく、状況に応じて組み合わされます。

  ok       決定ボタン。（OK）
  cancel   取り消しボタン。（Cancel）
  yes      はいボタン。（Yes）
  no       いいえボタン。（No）
  retry    再試行ボタン。（Retry）
  abort    中止ボタン。（Abort）
  ignore   無視して続行するボタン。（Ignore）


----------------------------------------------------------------
dialog — ファイル選択ダイアログ（2項目）
----------------------------------------------------------------

Windowsのファイル選択ダイアログに渡す文字です。

  open_title
    ダイアログのタイトルバーに出る文字。
    （Open a PDF file）

  pdf_filter
    ファイル種類の選択欄に出る文字。
    （PDF files (*.pdf)）
    ※ (*.pdf) の部分はWindowsが解釈する拡張子の指定です。
      形式を変えず、そのまま残してください。


----------------------------------------------------------------
keymap — キーの一覧画面（10項目）
----------------------------------------------------------------
F1 で開くキーボードショートカット一覧画面の文字です。

  title
    画面のタイトル。（Keyboard shortcuts）

  close
    閉じるボタンのツールチップ。（Close）

  hint
    操作方法をひとこと説明するテキスト。
    （Choose a row and press Enter, or press the shortcut itself.）

  group_file
    一覧の「ファイル」グループの見出し。（File）

  group_edit
    一覧の「編集」グループの見出し。（Edit）

  group_view
    一覧の「表示」グループの見出し。（View）

  group_nav
    一覧の「移動」グループの見出し。（Moving around）

  group_tab
    一覧の「タブ」グループの見出し。（Tabs）

  group_panel
    一覧の「パネルと目印」グループの見出し。（Panels and marks）

  group_search
    一覧の「検索」グループの見出し。（Search）


----------------------------------------------------------------
tab — タブ（4項目）
----------------------------------------------------------------

  untitled
    PDFを開いていないタブに表示される名前。（Untitled）

  close
    タブを閉じるボタンのツールチップ。（Close tab）

  next
    次のタブへ切り替えるキーのツールチップ。（Next tab）

  prev
    前のタブへ切り替えるキーのツールチップ。（Previous tab）


================================================================
例: フランス語を追加する（fr.json）
================================================================

1. このフォルダの en.json を fr.json としてコピーします。

2. "locale" セクションを編集します。

     "locale": {
       "language": "Langue",
       "language_name": "Français"
     }

3. 各キーの文字列をフランス語に翻訳します。
   キー名（左側）は変更しないでください。
   変更すると、そのキーは見つからなくなり英語のまま出ます。

4. アプリを再起動します。
   設定画面の言語一覧に "Français" が表示されます。

5. 実際に切り替えて画面を確認します。
   英語のまま残っている箇所があれば、そこが未翻訳です。

================================================================